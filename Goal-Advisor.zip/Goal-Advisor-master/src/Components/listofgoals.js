import React from 'react';

const listofgoals = [

    {
        goal:"Learn React", duedate: "Jan 1st 2000"
    }
]

export default listofgoals;